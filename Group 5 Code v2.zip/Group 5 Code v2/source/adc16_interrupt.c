/*
 * Copyright (c) 2013 - 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "MKL25Z4.h"
#include "fsl_debug_console.h"
#include "board.h"
#include "fsl_adc16.h"
#include "fsl_tpm.h"

#include "pin_mux.h"
#include "clock_config.h"

#include "pid.h"
#include "tpm.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define DEMO_ADC16_BASE ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U
#define DEMO_ADC16_USER_CHANNEL 12U /*PTE20, ADC0_SE0 */

#define DEMO_ADC16_IRQn ADC0_IRQn
#define DEMO_ADC16_IRQ_HANDLER_FUNC ADC0_IRQHandler

/* The Flextimer instance/channel used for board */
#define BOARD_TPM_BASEADDR TPM1
#define BOARD_FIRST_TPM_CHANNEL 0U
#define BOARD_SECOND_TPM_CHANNEL 1U

/* Get source clock for TPM driver */
#define TPM_SOURCE_CLOCK CLOCK_GetFreq(kCLOCK_PllFllSelClk)


/* Servo Parameters */
#define XMIN (105) //105 //85
#define XMAX (175) //215 //195
#define XLEVEL (150)	//150

#define YMIN (140)  //75 //120
#define YMAX (205) //180 //225
#define YLEVEL (170) //130 //170

//for direction, 0 is normal and 1 is reversed
#define XDIR (0)
#define YDIR (1)

#define XSetPoint (1048)
#define YSetPoint (1048)

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void Init_Read_X(void);
void Init_Read_Y(void);
void delay(uint32_t Delay_Count);
void Long_delay(uint32_t Delay_Count);
void Get_XY(void);
void Set_PWM_Duty(uint8_t X_Pos, uint8_t RevX, uint8_t Y_Pos, uint8_t RevY); //Revn = 0 is normal =1 is rev

/*******************************************************************************
 * Variables
 ******************************************************************************/
PID* pXservo;
PID* pYservo;

volatile bool g_Adc16ConversionDoneFlag = false;
volatile uint32_t g_Adc16ConversionValue;
volatile uint32_t g_Adc16InterruptCounter;
volatile uint32_t g_ADC_Channel_No_Var = 13U;
volatile uint32_t g_ADC_Info;

//Variables used in the PID controllers
volatile float g_XDInput, g_YDInput, g_XITerm, g_YITerm;
volatile uint32_t g_SysTick [2], g_XPresentTime, g_YPresentTime,  g_XDeltaTime, g_YDeltaTime;
volatile int32_t g_XPrevious_Time, g_Xerror, g_Xsetpoint, g_XlastInput;
volatile int32_t g_YPrevious_Time, g_Yerror, g_Ysetpoint, g_YlastInput;
volatile uint8_t g_XoutMax, g_XoutMin, g_XOutput, ServoXDir, XLevel;
volatile uint8_t g_YoutMax, g_YoutMin, g_YOutput, ServoYDir, YLevel;
volatile float g_Xki, g_Xkd, g_Xkp, Xtest;
volatile float g_Yki, g_Ykd, g_Ykp, Ytest;

volatile uint8_t getCharValue = 0U;
volatile uint8_t updatedDutycycle1 = 85U, updatedDutycycle2 = 85U;
adc16_channel_config_t adc16ChannelConfigStruct;
volatile float  g_A_Cal, g_B_Cal, g_C_Cal, g_D_Cal, g_E_Cal, g_F_Cal;
volatile uint32_t g_X_Raw, g_Y_Raw, g_X_Cal, g_Y_Cal;

/*******************************************************************************
 * Code
 ******************************************************************************/

// SysTick IRQ handler:
void SysTick_Handler(void)
{
//static uint8_t OutState=0;

//GPIOE_PTOR |= (1<<5);

//	    gpio_pin_config_t SysTickOut_config = {
//	        .pinDirection = kGPIO_DigitalOutput,
//	        .outputLogic = OutState
//	    };
//	    OutState ^= 1U;
//	    /* Initialize GPIO functionality on pin PTE6 (pin 6)  */
//	    GPIO_PinInit(BOARD_INITPINS_SysTickOut_GPIO, BOARD_INITPINS_SysTickOut_PIN, &SysTickOut_config);

g_SysTick [0] += 1u;
g_SysTick [1] += 1u;
}


void DEMO_ADC16_IRQ_HANDLER_FUNC(void)
{
    g_Adc16ConversionDoneFlag = true;
    /* Read conversion result to clear the conversion completed flag. */
    g_Adc16ConversionValue = ADC16_GetChannelConversionValue(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP);
    g_Adc16InterruptCounter++;
}

/*!
 * @brief Main function ***************************************
 */
int main(void)
{
	TPM2_Init();
	pXservo = InitPID();
	pYservo = InitPID();

	if(!pXservo || !pYservo)
		return -1;

	SetPIDLimits(pXservo, XMIN, XMAX);
	SetPIDLimits(pYservo, YMIN, YMAX);


	//Set Proportional, Integral and Derivative Value
	SetPIDGain(pXservo, 0.04, 0.000001, 0.0005);
	SetPIDGain(pYservo, 0.03, 0.000001, 0.0005);

	//Set PID Setpoint
	SetPIDSetpoint(pXservo, XSetPoint); //1020
	SetPIDSetpoint(pYservo, YSetPoint); //1000

    // Configure sys tick for 0.1 mSec per tick
	SysTick_Config(CLOCK_GetFreq(kCLOCK_CoreSysClk)/(4370UL));  //437 was determined empirically
    g_SysTick [0] = 0;
    g_SysTick [1] = 0;

	// populate conversion from you matlab calculations to give X = 1 to 4000 and Y = 1 to 4000
 	g_X_Raw=0; g_Y_Raw=0;
	g_A_Cal=0.645 ; g_B_Cal= 0.024; g_C_Cal= -277.2290;  //Conversion matrix constants ABC and DEF for X and Y
	g_D_Cal=0.0401 ; g_E_Cal=0.7685; g_F_Cal=-451.6048;
	g_X_Cal=0; g_Y_Cal=0;
	uint32_t Option_value, i;
    adc16_config_t adc16ConfigStruct;
    //adc16_channel_config_t adc16ChannelConfigStruct;

    tpm_config_t tpmInfo;
    tpm_chnl_pwm_signal_param_t tpmParam[2];

    /* Configure tpm params with frequency 24kHZ */
    tpmParam[0].chnlNumber = (tpm_chnl_t)BOARD_FIRST_TPM_CHANNEL;
    tpmParam[0].level = kTPM_HighTrue;
    tpmParam[0].dutyCyclePercent = updatedDutycycle1;

    tpmParam[1].chnlNumber = (tpm_chnl_t)BOARD_SECOND_TPM_CHANNEL;
    tpmParam[1].level = kTPM_HighTrue;
    tpmParam[1].dutyCyclePercent = updatedDutycycle2;


    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    EnableIRQ(DEMO_ADC16_IRQn);

    PRINTF("\r\nTilt Table Control Code: \r\n");

    /* Select the clock source for the TPM counter as kCLOCK_PllFllSelClk */
    CLOCK_SetTpmClock(1U);
    /*
      * tpmInfo.prescale = kTPM_Prescale_Divide_1;
      * tpmInfo.useGlobalTimeBase = false;
      * tpmInfo.enableDoze = false;
      * tpmInfo.enableDebugMode = false;
      * tpmInfo.enableReloadOnTrigger = false;
      * tpmInfo.enableStopOnOverflow = false;
      * tpmInfo.enableStartOnTrigger = false;
      * tpmInfo.enablePauseOnTrigger = false;
      * tpmInfo.triggerSelect = kTPM_Trigger_Select_0;
      * tpmInfo.triggerSource = kTPM_TriggerSource_External;
      */

     TPM_GetDefaultConfig(&tpmInfo);
     /* Initialize TPM module */
     TPM_Init(BOARD_TPM_BASEADDR, &tpmInfo);

     TPM_SetupPwm(BOARD_TPM_BASEADDR, tpmParam, 2U, kTPM_EdgeAlignedPwm, 100U, TPM_SOURCE_CLOCK);
     TPM_StartTimer(BOARD_TPM_BASEADDR, kTPM_SystemClock);
     g_SysTick [1] = 0u;  //Zero g_SysTick[1] so you can somewhat sync with the servo, every 100 ticks =10ms
    /*
     * adc16ConfigStruct.referenceVoltageSource = kADC16_ReferenceVoltageSourceVref;
     * adc16ConfigStruct.clockSource = kADC16_ClockSourceAsynchronousClock;
     * adc16ConfigStruct.enableAsynchronousClock = true;
     * adc16ConfigStruct.clockDivider = kADC16_ClockDivider8;
     * adc16ConfigStruct.resolution = kADC16_ResolutionSE12Bit;
     * adc16ConfigStruct.longSampleMode = kADC16_LongSampleDisabled;
     * adc16ConfigStruct.enableHighSpeed = false;
     * adc16ConfigStruct.enableLowPower = false;
     * adc16ConfigStruct.enableContinuousConversion = false;
     */

     ADC16_GetDefaultConfig(&adc16ConfigStruct);
#ifdef BOARD_ADC_USE_ALT_VREF
    adc16ConfigStruct.referenceVoltageSource = kADC16_ReferenceVoltageSourceValt;
#endif    
    ADC16_Init(DEMO_ADC16_BASE, &adc16ConfigStruct);
    ADC16_EnableHardwareTrigger(DEMO_ADC16_BASE, false); /* Make sure the software trigger is used. */
#if defined(FSL_FEATURE_ADC16_HAS_CALIBRATION) && FSL_FEATURE_ADC16_HAS_CALIBRATION
    if (kStatus_Success == ADC16_DoAutoCalibration(DEMO_ADC16_BASE))
    {
        PRINTF("ADC16_DoAutoCalibration() Done.\r\n");
    }
    else
    {
        PRINTF("ADC16_DoAutoCalibration() Failed.\r\n");
    }
#endif /* FSL_FEATURE_ADC16_HAS_CALIBRATION */

    void ADC16_SetHardwareAverage(ADC_Type *base, adc16_hardware_average_mode_t kADC16_HardwareAverageCount16);
    adc16ChannelConfigStruct.channelNumber = DEMO_ADC16_USER_CHANNEL;
    adc16ChannelConfigStruct.enableInterruptOnConversionCompleted = true; /* Enable the interrupt. */
#if defined(FSL_FEATURE_ADC16_HAS_DIFF_MODE) && FSL_FEATURE_ADC16_HAS_DIFF_MODE
    adc16ChannelConfigStruct.enableDifferentialConversion = false;
#endif /* FSL_FEATURE_ADC16_HAS_DIFF_MODE */

    g_Adc16InterruptCounter = 0U;
    while(1)
    {

    /*The max and min values for the servo are 220 and 80
    	in the min value is supposed to be down for the servo, but
     *  in many cases it works out to be up instead and vice versa
     *  This might affect one or both servos depending on how they are mounted
     *  Check servo motion with the function #2
     * Print a note to terminal */

    do{
    PRINTF("\r\n Test g_SysTick = %d",g_SysTick[0]);
    PRINTF("\r\n core Clk = %d",CLOCK_GetFreq(kCLOCK_CoreSysClk));
    PRINTF("\r\n1= Read and Display X and Y raw values, Will stop after 20 samples");
    PRINTF("\r\n2= Test Servos:  X servo Low then Y Low  then X Hi then Y Hi then both level");
    PRINTF("\r\n3= Display calibrated X & Y values");
    PRINTF("\r\n4= Run your Code");
    PRINTF("\r\n5= Center X and Y Servo");
    PRINTF("\r\n6= Center Y and X Servo");
    PRINTF("\r\n7= Test X and Y Servo Range");
    PRINTF("\r\nSelections: Type single key 1 to 7\r\n");
	Set_PWM_Duty(XLEVEL, XDIR, YLEVEL , YDIR);  //Centering Servos
    Option_value = GETCHAR()- 0x30U;
    PRINTF("\r\nYou Entered: %d\r\n", Option_value);
    } while (Option_value > 9U);  //Continue until Option_value less than or equal 9

    switch (Option_value)
		{
    case 1:
    	    PRINTF("XRaw,YRaw\r\n" );
    		for (i=0; i<20; i++)
    		{
    			Get_XY();
    			PRINTF("%4.d %4.d\r\n", g_X_Raw, g_Y_Raw  );
    		}
    		break;
    case 2:
    		Set_PWM_Duty(XMIN, XDIR, YLEVEL, YDIR);
    		Long_delay(50LU);

    		Set_PWM_Duty(XMIN, XDIR, YMIN, YDIR);
    		Long_delay(50LU);

    		Set_PWM_Duty(XMAX, XDIR, YMIN, YDIR);
    		Long_delay(50LU);
    		Set_PWM_Duty(XMAX, XDIR, YMAX, YDIR);
    		Long_delay(50LU);
    		Set_PWM_Duty(XLEVEL, XDIR, YLEVEL, YDIR);
    		break;
    case 3:
    	    /*Print out 20 Raw and Calibrated values   */
		    for (i=0; i<20; i++)
		       {
			   Get_XY();
	    	   g_X_Cal = g_A_Cal * g_X_Raw + g_B_Cal * g_Y_Raw + g_C_Cal;
	    	   g_Y_Cal = g_D_Cal * g_X_Raw + g_E_Cal * g_Y_Raw + g_F_Cal;

			   PRINTF("RAW: X:%4.d Y:%4.d CALIBRATED: X:%4.d Y:%4.d\r\n", g_X_Raw, g_Y_Raw, g_X_Cal, g_Y_Cal);
		       }
    		break;
    case 4:  /******************* Put Your Controller Code Here:  Case #4 **************/
    		Set_PWM_Duty(XLEVEL, XDIR, YLEVEL, YDIR);  //Start Level

    		PRINTF("\r\nHit any single char to start, Reset to end\r\n");
    		Option_value = GETCHAR()- 0x30U;
    		g_SysTick[0] = 0;   //reset the systick to zero

    		static uint8_t OutState=0;

    		//Needed
    		g_XPrevious_Time = 0U;
    		g_YPrevious_Time = 0U ;
    		//Needed

    		g_XlastInput = 1000;
    		g_YlastInput = 1000;

    		while (1){  // loop to run the 2-axis PID controllers continoutly

    			//This syncs the PID with the PWM cycle/ one update per 10ms pwm cycle
    		while (!(TPM_GetStatusFlags(BOARD_TPM_BASEADDR ) & 0x100U )) continue; //Wait here for new PWM cycle
    			        TPM_ClearStatusFlags(BOARD_TPM_BASEADDR, 0x103U);

    				    gpio_pin_config_t SysTickOut_config = {
    				        .pinDirection = kGPIO_DigitalOutput,
    				        .outputLogic = OutState
    				    };
    				    OutState ^= 1U;
    				    GPIO_PinInit(BOARD_INITPINS_SysTickOut_GPIO, BOARD_INITPINS_SysTickOut_PIN, &SysTickOut_config);

    	    //we get calibrated x,y generate an error from -1000 to +1000 and
    	    //map it to a command for servo 85 to 215
    		Get_XY();   //get a raw value point and calibrate it
    		g_XPresentTime = g_SysTick[0];
    		g_YPresentTime =  g_XPresentTime;  //Thus both delta times will be the same
    		g_X_Cal = g_A_Cal *(float) g_X_Raw + g_B_Cal * (float)g_Y_Raw + g_C_Cal;
    		g_Y_Cal = g_D_Cal * (float)g_X_Raw + g_E_Cal * (float)g_Y_Raw + g_F_Cal;


    		//Run the PID controller for X axis

    		g_XDeltaTime = g_XPresentTime  - g_XPrevious_Time;  //  save the time in 1/10 ms
    		g_Xerror = XSetPoint - g_X_Cal;  //as long as the set point is 0, same as PoV?
    		g_XOutput = GetPIDOutput(pXservo, (float)g_X_Cal, (float)g_XDeltaTime);

    		//Run the PID controller for Y axis

    		g_YDeltaTime =  g_YPresentTime  - g_YPrevious_Time;  //  save the time in 1/10 ms
    		g_Yerror = YSetPoint - g_Y_Cal;  //as long as the set point is 0, same as PoV?
    		g_YOutput = GetPIDOutput(pYservo, (float)g_Y_Cal, (float)g_YDeltaTime);

    		//*************Output Stuff*******************************//
	        /*Remember some variables for next time*/
    		g_XPrevious_Time = g_XPresentTime ;
    		g_YPrevious_Time = g_YPresentTime ;
    		Set_PWM_Duty(g_XOutput, XDIR, g_YOutput, YDIR);
    		PRINTF("Err: X:%d -- Y:%d\r\n",g_Xerror,g_Yerror);
    		//PRINTF("Outs X:%4.d Y:%4.d\r\n", g_XOutput, g_YOutput);
    		} //END of
    		//PRINTF("Der %f %f\r\n",g_XDInput, g_YDInput);

    		break;

    case 5:  //Center X Servo
			Set_PWM_Duty(XLEVEL, XDIR, YLEVEL , YDIR);  //X servo should be centered and Y low
			break;
    case 6:  //Center Y Servo
			Set_PWM_Duty(XLEVEL, XDIR, YLEVEL, YDIR);  //X servo should be low and Y centered
			break;
    case 7:
    		PRINTF("Testing the X Servo Range");
    		for(int i = XMIN; i <= XMAX; i++){
    			Set_PWM_Duty(i, XDIR, YLEVEL, YDIR);
    			PRINTF("%d", i);
    			Long_delay(1LU);
    		}
    		PRINTF("Testing the Y Servo Range");
    		for(int j = YMIN; j <= YMAX; j++){
    			Set_PWM_Duty(XLEVEL, XDIR, j, YDIR);
    			PRINTF("%d", j);
    			Long_delay(1LU);
    		}
    		break;
    default:
    		PRINTF("\r\nYou Entered bad value=: %d\r\n", Option_value);
    		break;
		}






//
//     for (x=50; x<250 ; x += 5)
//     {
//    	 for (y=50;y<250;y += 5)
//    	 {
//    		 delay(20000U);
//    		 Set_PWM_Duty(x,0,y,0);
//    		 Get_XY();
//    	 }
//     }
    }  //End of principle inf while loop

  }


/*******************************************************************************
 * User Function  Set_PWM_Duty
 ******************************************************************************/

void Set_PWM_Duty(uint8_t X_Pos, uint8_t RevX, uint8_t Y_Pos, uint8_t RevY)
{
	if(X_Pos > 220) X_Pos = 220;   //Upper limit
	if(X_Pos < 80)  X_Pos = 80;    //Lower limit
	if(Y_Pos > 220) Y_Pos = 220;   //Upper limit
	if(Y_Pos < 80)  Y_Pos = 80;    //Lower limit
	if(RevX) X_Pos = 300 - X_Pos;
	if(RevY) Y_Pos = 300 - Y_Pos;

	TPM_UpdatePwmDutycycle(BOARD_TPM_BASEADDR, (tpm_chnl_t)BOARD_SECOND_TPM_CHANNEL, kTPM_EdgeAlignedPwm,Y_Pos);
    TPM_UpdatePwmDutycycle(BOARD_TPM_BASEADDR, (tpm_chnl_t)BOARD_FIRST_TPM_CHANNEL, kTPM_EdgeAlignedPwm,X_Pos);

	//PRINTF("The duty cycle was successfully updated!\r\n");

}

/*******************************************************************************
 * User Function  Get_XY
 * volatile uint32_t g_X_Raw, g_Y_Raw, g_A_Cal, g_B_Cal, g_C_Cal, g_D_Cal, g_E_Cal, g_F_Cal, g_X_Cal, g_Y_Cal;
 *
 *        0,2k__H__2k,2k
 *         |          |
 *         |          |    H = connector
 *         |0,0___2k,0|
 *
 *
 ******************************************************************************/

  void Get_XY(void) //Returns the RAW values as global floats, need to be calibrated
  {

	  /* Get X position */
	            g_Adc16ConversionDoneFlag = false;
	            Init_Read_X ();
	            adc16ChannelConfigStruct.channelNumber = 13U ;
	            delay(100U);  //to let the touch change over settle and charge sample cap
	            ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
	            while (!g_Adc16ConversionDoneFlag)
	            {
	            }

	            g_X_Raw = g_Adc16ConversionValue;

	  /* Get Y  position */
	            g_Adc16ConversionDoneFlag = false;
	            Init_Read_Y ();
	            adc16ChannelConfigStruct.channelNumber = 12U ;
	            delay(100U);  //to let the touch change over settle and charge sample cap
	            ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
	            while (!g_Adc16ConversionDoneFlag)
	            {
	            }

	            g_Y_Raw = g_Adc16ConversionValue;

  }

  /*******************************************************************************
   * User Function  delay
   ******************************************************************************/
  void delay(uint32_t Delay_Count)
  {
      volatile uint32_t i = 0;
      for (i = 0; i < Delay_Count; ++i)
      {
        	  __asm("NOP"); /* delay */
          	  __asm("NOP"); /* delay */
          	  __asm("NOP"); /* delay */
          	  __asm("NOP"); /* delay */
      }
  }


  /*******************************************************************************
   * User Function  Long_delay
   ******************************************************************************/
  void Long_delay(uint32_t Delay_Count)
  {
      volatile uint32_t i = 0, k = 0;
      for (i = 0; i < Delay_Count; ++i)
      {
          for(k=0; k<60000U; k++)
          {
        	  __asm("NOP"); /* delay */
          	  __asm("NOP"); /* delay */
          	  __asm("NOP"); /* delay */
          	  __asm("NOP"); /* delay */
          }
      }
  }

  /*******************************************************************************
   * User Function  Init_Read_X
   ******************************************************************************/

  void Init_Read_X (void)
  {
          // The ADC_Channel No Should be = 13U;
  	    gpio_pin_config_t Left_config = {
  	        .pinDirection = kGPIO_DigitalOutput,
  	        .outputLogic = 0U
  	    };
  	    /* Initialize GPIO functionality on pin PTB8 (pin 47)  */
  	    GPIO_PinInit(BOARD_INITPINS_Left_GPIO, BOARD_INITPINS_Left_PIN, &Left_config);

  	    gpio_pin_config_t Right_config = {
  	        .pinDirection = kGPIO_DigitalOutput,
  	        .outputLogic = 1U
  	    };
  	    /* Initialize GPIO functionality on pin PTB9 (pin 48)  */
  	    GPIO_PinInit(BOARD_INITPINS_Right_GPIO, BOARD_INITPINS_Right_PIN, &Right_config);

  	    gpio_pin_config_t Back_config = {
  	        .pinDirection = kGPIO_DigitalInput,
  	        .outputLogic = 1U
  	    };
  	    /* Initialize GPIO functionality on pin PTB10 (pin 49)  */
  	    GPIO_PinInit(BOARD_INITPINS_Back_GPIO, BOARD_INITPINS_Back_PIN, &Back_config);

  	    gpio_pin_config_t Front_config = {
  	        .pinDirection = kGPIO_DigitalInput,
  	        .outputLogic = 0U
  	    };
  	    /* Initialize GPIO functionality on pin PTB11 (pin 50)  */
  	    GPIO_PinInit(BOARD_INITPINS_Front_GPIO, BOARD_INITPINS_Front_PIN, &Front_config);

  	    //PRINTF("Init X \r\n" );

  }

  /*******************************************************************************
   * User Function  Init_Read_Y
   ******************************************************************************/
  void Init_Read_Y(void)
  {
  	    // The ADC_Channel No Should be = 12U;
  	    gpio_pin_config_t Left_config = {
  	        .pinDirection = kGPIO_DigitalInput,
  	        .outputLogic = 0U
  	    };
  	    /* Initialize GPIO functionality on pin PTB8 (pin 47)  */
  	    GPIO_PinInit(BOARD_INITPINS_Left_GPIO, BOARD_INITPINS_Left_PIN, &Left_config);

  	    gpio_pin_config_t Right_config = {
  	        .pinDirection = kGPIO_DigitalInput,
  	        .outputLogic = 1U
  	    };
  	    /* Initialize GPIO functionality on pin PTB9 (pin 48)  */
  	    GPIO_PinInit(BOARD_INITPINS_Right_GPIO, BOARD_INITPINS_Right_PIN, &Right_config);

  	    gpio_pin_config_t Back_config = {
  	        .pinDirection = kGPIO_DigitalOutput,
  	        .outputLogic = 1U
  	    };
  	    /* Initialize GPIO functionality on pin PTB10 (pin 49)  */
  	    GPIO_PinInit(BOARD_INITPINS_Back_GPIO, BOARD_INITPINS_Back_PIN, &Back_config);

  	    gpio_pin_config_t Front_config = {
  	        .pinDirection = kGPIO_DigitalOutput,
  	        .outputLogic = 0U
  	    };
  	    /* Initialize GPIO functionality on pin PTB11 (pin 50)  */
  	    GPIO_PinInit(BOARD_INITPINS_Front_GPIO, BOARD_INITPINS_Front_PIN, &Front_config);

  	    //PRINTF("Init Y \r\n" );

  }
