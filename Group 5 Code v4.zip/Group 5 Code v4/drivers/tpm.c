//#include "derivative.h" /* include peripheral declarations */
#include "tpm.h"
#include <string.h>

volatile unsigned long		ch1Time, ch2Time;
volatile unsigned long		lastCh1Time, lastCh2Time;
volatile unsigned long		ch1Ovf, ch2Ovf, ovf;
volatile unsigned long		lastCh1Ovf, lastCh2Ovf;
volatile unsigned long		testOvf = 0;

volatile unsigned long		buf1[FILTER_SIZE], buf2[FILTER_SIZE];
volatile short				ptr1, ptr2;
volatile short				count1, count2;

void GetTime(unsigned long* t1, unsigned long* t2)
{
	short			i;
	unsigned long	f1 = 0, f2 = 0;

	if (count1 >= FILTER_SIZE && count2 >= FILTER_SIZE)
	{
		for (i = 0; i < FILTER_SIZE; i++)
		{
			f1 += buf1[i] / FILTER_SIZE;
			f2 += buf2[i] / FILTER_SIZE;
		}
	}
	else
	{
		for (i = 0; i < count1; i++)
			f1 += buf1[i] / count1;

		for (i = 0; i < count2; i++)
			f2 += buf2[i] / count2;
	}

	*t1 = f1;
	*t2 = f2;
}

void TPM2_Init(void)
{
	ch1Time = 0;
	ch2Time = 0;
	lastCh1Time = 0;
	lastCh2Time = 0;

	ovf = 0;
	ch1Ovf = 0;
	ch2Ovf = 0;
	lastCh1Ovf = 0;
	lastCh2Ovf = 0;

	ptr1 = 0;
	ptr2 = 0;
	count1 = 0;
	count2 = 0;

	memset(buf1, 0, sizeof(buf1));
	memset(buf2, 0, sizeof(buf2));
}
